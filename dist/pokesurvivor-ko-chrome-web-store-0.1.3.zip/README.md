# PokéSurvivor 한국어 패치 · 도감 티어

Chrome Web Store 제출 패키지 0.1.3 / 한국어 패치 0.4.6.

공식 게임 https://pokesurvivor.com/ 에서 메뉴·DOM·Canvas를 번역하고 보유 포켓몬 이름 옆에만 작은 잠정 티어 배지를 표시합니다. 별도 티어 메뉴나 수치 패널은 없습니다. 미평가·미보유에는 배지를 붙이지 않습니다. 게임 계정과 수치를 바꾸지 않습니다.

소스·평가 기준: https://github.com/GuenohPark/pokesurvivor
개인정보: PRIVACY.md. 제3자 라이선스: THIRD-PARTY-NOTICES.md 및 licenses/.

스토어에서 설치한 확장은 Chrome의 공식 업데이트 절차로 갱신됩니다. 압축해제 설치판은 자동 전환되지 않습니다. 새 버전은 열린 게임을 새로고침한 뒤 적용됩니다. 진행 중인 판은 먼저 마치세요.
